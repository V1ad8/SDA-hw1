// power: compute n raise to k
// n       - the base
// k       - the exponente
// @return - n raise to k
int power(int n, int k) {
	// base case: n raise to 0 is 1
	if (!k)
	{
		return 1;
	}

	if (...) {
		return 123;
	}
	// ...
}
