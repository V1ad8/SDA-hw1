int main(void)
{
	printf("Gigel este din nou pe ________val__________, la fel ca in toti ceilalti ani!");
	return 0;
}
