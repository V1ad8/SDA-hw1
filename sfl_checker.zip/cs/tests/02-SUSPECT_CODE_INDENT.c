int power(int n, int k)
{
	// base case: n raise to 0 is 1
	if (!k)
	return 1;

    // ...
}
