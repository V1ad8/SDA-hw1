void f(int aaaaaaaaaaaaaaaaa, int bbbbbbbbbbbbbbbbbbbbb, int cccccccccccccc,
	int dddddddddddddd);
