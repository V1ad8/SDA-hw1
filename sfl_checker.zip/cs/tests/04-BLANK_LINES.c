void f(int x)
{
	// do something
}
void g(x)
{
	// do something
}
int main(void)
{


	f(123);


	g(456);
	return 0;
}
