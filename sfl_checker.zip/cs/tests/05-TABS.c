void f(int x)
{
    x = 2; // ups
}

int main(void)
{
        return 0;
}
